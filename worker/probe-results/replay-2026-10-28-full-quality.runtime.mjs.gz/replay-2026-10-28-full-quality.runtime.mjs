// worker/probe-kernel/replay-full-quality.ts
import { createHash } from "node:crypto";
import { readFileSync, renameSync, writeFileSync } from "node:fs";
import { isAbsolute, resolve, sep } from "node:path";
import { performance } from "node:perf_hooks";

// worker/src/static-search-int8.ts
function selectTop(scores, k, ids) {
  const heap = [];
  const worse = (a, b) => a.score < b.score || a.score === b.score && a.index > b.index;
  for (let i = 0; i < scores.length; i++) {
    const index2 = ids?.[i] ?? i;
    const score = scores[i];
    if (heap.length === k && (score < heap[0].score || score === heap[0].score && index2 >= heap[0].index)) continue;
    const item = { index: index2, score };
    if (heap.length < k) {
      let at = heap.length;
      heap.push(item);
      while (at > 0) {
        const parent = at - 1 >>> 1;
        if (!worse(item, heap[parent])) break;
        heap[at] = heap[parent];
        at = parent;
      }
      heap[at] = item;
    } else {
      let at = 0;
      while (at * 2 + 1 < k) {
        let child = at * 2 + 1;
        if (child + 1 < k && worse(heap[child + 1], heap[child])) child++;
        if (!worse(heap[child], item)) break;
        heap[at] = heap[child];
        at = child;
      }
      heap[at] = item;
    }
  }
  return heap.sort((a, b) => b.score - a.score || a.index - b.index);
}

// worker/src/full-search-index.ts
var FullSearchIndex = class _FullSearchIndex {
  constructor(count, dimensions, module2) {
    this.count = count;
    this.dimensions = dimensions;
    if (!Number.isSafeInteger(count) || count < 1 || count > 6e4 || dimensions !== 768) {
      throw new RangeError("Invalid full-index geometry");
    }
    this.normsOffset = Math.ceil(count * dimensions / 8) * 8;
    this.queryOffset = this.normsOffset + count * 8;
    this.outputOffset = this.queryOffset + dimensions * 8;
    const needed = this.outputOffset + count * 8;
    if (module2) {
      const exports = new WebAssembly.Instance(module2).exports;
      if (!(exports.memory instanceof WebAssembly.Memory) || typeof exports.int8 !== "function") {
        throw new RangeError("Missing exact int8 WASM kernel");
      }
      const pages = Math.ceil(needed / 65536);
      const current = exports.memory.buffer.byteLength / 65536;
      if (pages > current) exports.memory.grow(pages - current);
      this.buffer = exports.memory.buffer;
      this.kernel = exports.int8;
    } else {
      this.buffer = new ArrayBuffer(needed);
    }
    this.residentBytes = this.buffer.byteLength;
  }
  count;
  dimensions;
  buffer;
  normsOffset;
  queryOffset;
  outputOffset;
  kernel;
  residentBytes;
  static async load(manifest2, loadAsset2, module2, memorySample) {
    if (manifest2.index.kind !== "exact-int8" || manifest2.index.quantization !== "per-row-maxabs-rint-127") {
      throw new RangeError("Unsupported full-index quantization");
    }
    const result2 = new _FullSearchIndex(manifest2.passage_count, manifest2.dimensions, module2);
    const sample = (phase, bytes = 0) => memorySample?.({
      phase,
      resident_index_bytes: result2.residentBytes,
      current_asset_bytes: bytes
    });
    sample("allocated");
    const copyShard = async (path, offset, expected) => {
      const bytes = await loadAsset2(path);
      if (bytes.byteLength !== expected) throw new RangeError("Wrong int8 asset length");
      sample("asset-loaded:" + path, bytes.byteLength);
      new Uint8Array(result2.buffer, offset, expected).set(new Uint8Array(bytes));
      sample("asset-copied:" + path, bytes.byteLength);
    };
    let next = 0;
    for (const shard of manifest2.index.shards) {
      if (shard.start !== next || !Number.isSafeInteger(shard.count) || shard.count < 1 || shard.count > 4096 || next + shard.count > result2.count) throw new RangeError("Noncontiguous vector shards");
      await copyShard(shard.path, next * result2.dimensions, shard.count * result2.dimensions);
      next += shard.count;
    }
    if (next !== result2.count) throw new RangeError("Incomplete vector index");
    await copyShard(manifest2.index.norms_path, result2.normsOffset, result2.count * 8);
    const view = new DataView(result2.buffer);
    const norms = new Float64Array(result2.buffer, result2.normsOffset, result2.count);
    const integers = new Int8Array(result2.buffer, 0, result2.count * result2.dimensions);
    for (let row = 0; row < result2.count; row++) {
      const inverse = view.getFloat64(result2.normsOffset + row * 8, true);
      let squared = 0;
      for (let dim = 0; dim < result2.dimensions; dim++) {
        const value = integers[row * result2.dimensions + dim];
        if (value === -128) throw new RangeError("Invalid symmetric int8 value");
        squared += value * value;
      }
      if (!Number.isFinite(inverse) || inverse <= 0 || !squared || Math.abs(inverse * Math.sqrt(squared) - 1) > 1e-10) {
        throw new RangeError("Int8 normalization mismatch");
      }
      norms[row] = inverse;
    }
    if (new Uint8Array(new Uint16Array([1]).buffer)[0] !== 1) {
      throw new RangeError("Full int8 index requires a little-endian runtime");
    }
    sample("ready");
    return result2;
  }
  search(query, k) {
    if (query.length !== this.dimensions || !Number.isSafeInteger(k) || k < 1 || k > 1e3) {
      throw new RangeError("Invalid full-index query");
    }
    let squared = 0;
    for (let dim = 0; dim < this.dimensions; dim++) {
      const value = query[dim];
      if (typeof value !== "number" || !Number.isFinite(value)) throw new RangeError("Non-finite query");
      squared += value * value;
    }
    const norm = Math.sqrt(squared);
    if (!Number.isFinite(norm) || !norm) throw new RangeError("Invalid query norm");
    const normalized = new Float64Array(this.buffer, this.queryOffset, this.dimensions);
    for (let dim = 0; dim < this.dimensions; dim++) normalized[dim] = query[dim] / norm;
    const scores = new Float64Array(this.buffer, this.outputOffset, this.count);
    if (this.kernel) {
      this.kernel(0, this.queryOffset, this.normsOffset, this.outputOffset, 0, this.count, this.dimensions);
    } else {
      const vectors = new Int8Array(this.buffer, 0, this.count * this.dimensions);
      const norms = new Float64Array(this.buffer, this.normsOffset, this.count);
      for (let row = 0; row < this.count; row++) {
        let dot = 0;
        for (let dim = 0; dim < this.dimensions; dim++) dot += vectors[row * this.dimensions + dim] * normalized[dim];
        scores[row] = dot * norms[row];
      }
    }
    return selectTop(scores, Math.min(k, this.count));
  }
};

// worker/probe-kernel/replay-full-quality.ts
var [
  assetsArgument,
  sourceArgument,
  queriesArgument,
  outputArgument,
  wasmArgument,
  frozenArgument,
  restorationArgument,
  ...extra
] = process.argv.slice(2);
if (![
  assetsArgument,
  sourceArgument,
  queriesArgument,
  outputArgument,
  wasmArgument,
  frozenArgument,
  restorationArgument
].every(Boolean) || extra.length) {
  throw new Error("Usage: replay-full-quality.mjs PACKED_DIR SOURCE_DIR QUERY_VECTORS OUTPUT SCAN_WASM FROZEN_QUERIES RESTORATION_JSON");
}
var started = performance.now();
var sha = (bytes) => createHash("sha256").update(bytes).digest("hex");
var archiveSha = "8f3fd29b369ae41f1474e052e0eef931a23ca7437c99640adbc6bc13d519c65c";
var sourceCommit = "fa3f4ec3724949a98b2b510949cf8efe405baf8a";
var restorationBytes = readFileSync(resolve(restorationArgument));
var restoration = JSON.parse(restorationBytes.toString("utf8"));
if (restoration.kind !== "historical-full-search-artifact-restoration" || restoration.artifact_sha256 !== archiveSha || restoration.run_id !== 40448979121 || restoration.source_commit !== sourceCommit) throw new Error("Historical restoration pin mismatch");
var sourceFiles = [
  "worker/src/full-search-index.ts",
  "worker/src/static-search-int8.ts",
  "worker/probe-kernel/scan.wat",
  "worker/probe-kernel/scan.wasm",
  "worker/probe-kernel/build.mjs"
];
var sourceHashes = Object.fromEntries(sourceFiles.map((path) => {
  const checksum = sha(readFileSync(resolve(process.cwd(), path)));
  if (restoration.source_sha256?.[path] !== checksum) {
    throw new Error("Historical runtime source mismatch: " + path);
  }
  return [path, checksum];
}));
var wasmBytes = readFileSync(resolve(wasmArgument));
if (sha(wasmBytes) !== sourceHashes["worker/probe-kernel/scan.wasm"]) {
  throw new Error("Supplied WASM differs from the restored runtime");
}
var assets = resolve(assetsArgument);
var source = resolve(sourceArgument);
var output = resolve(outputArgument);
var manifestBytes = readFileSync(resolve(assets, "probe.json"));
var manifest = JSON.parse(manifestBytes.toString("utf8"));
var sourceBytes = readFileSync(resolve(source, "probe.json"));
var original = JSON.parse(sourceBytes.toString("utf8"));
if (restoration.canonical_manifest_sha256 !== sha(sourceBytes) || restoration.packed_manifest_sha256 !== sha(manifestBytes) || manifest.synthetic !== false || original.synthetic !== false || manifest.passage_count !== 40575 || original.rows.length !== 40575 || manifest.source_manifest_sha256 !== sha(sourceBytes) || manifest.source_rows_sha256 !== original.rows_sha256) {
  throw new Error("Historical packed/source manifest mismatch");
}
async function loadAsset(path) {
  const target = resolve(assets, path);
  if (isAbsolute(path) || !target.startsWith(assets + sep)) throw new Error("Unsafe packed asset path");
  const bytes = readFileSync(target);
  const identity = manifest.files[path];
  if (!identity || bytes.length !== identity.bytes || sha(bytes) !== identity.sha256) {
    throw new Error("Packed asset checksum mismatch: " + path);
  }
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}
var metadata = new DataView(await loadAsset(manifest.metadata.path));
if (manifest.metadata.row_bytes !== 128 || metadata.byteLength !== manifest.passage_count * 128) {
  throw new Error("Unsupported row metadata");
}
var sourceIndices = [];
var previousId = "";
for (let position = 0; position < manifest.passage_count; position++) {
  const offset = position * 128;
  const sourceIndex = metadata.getUint32(offset + 52, true);
  const id = Buffer.from(metadata.buffer, offset, 32).toString("hex");
  const row = original.rows[sourceIndex];
  if (!row || row.id !== id || position && id <= previousId || row.paper_id !== manifest.paper_ids[metadata.getUint32(offset + 32, true)] || row.chunk_index !== metadata.getUint32(offset + 36, true) || row.start !== metadata.getUint32(offset + 40, true) || row.end !== metadata.getUint32(offset + 44, true)) throw new Error("Packed row mapping mismatch");
  previousId = id;
  sourceIndices.push(sourceIndex);
}
if (new Set(sourceIndices).size !== manifest.passage_count) throw new Error("Source row mapping is not bijective");
var queryBytes = readFileSync(resolve(queriesArgument));
var frozenBytes = readFileSync(resolve(frozenArgument));
var queryMetadata = JSON.parse(readFileSync(resolve(queriesArgument) + ".json", "utf8"));
if (queryMetadata.count !== 2064 || queryMetadata.dimensions !== 768 || queryMetadata.vectors_sha256 !== sha(queryBytes) || queryMetadata.query_manifest_sha256 !== sha(frozenBytes) || restoration.query_vectors_sha256 !== sha(queryBytes) || restoration.query_manifest_sha256 !== sha(frozenBytes) || queryMetadata.encoder_signature !== original.embeddings.encoder_signature || queryBytes.length !== queryMetadata.count * 768 * 4) throw new Error("Query vector provenance mismatch");
var queries = new Float32Array(queryBytes.buffer.slice(
  queryBytes.byteOffset,
  queryBytes.byteOffset + queryBytes.byteLength
));
var module = new WebAssembly.Module(wasmBytes);
var index = await FullSearchIndex.load(manifest, loadAsset, module);
var jsIndex = await FullSearchIndex.load(manifest, loadAsset);
var crosschecks = new Set(Array.from({ length: 64 }, (_, position) => Math.floor(position * (queryMetadata.count - 1) / 63)));
var rankings = [];
var wall = [];
var maxScoreDifference = 0;
for (let q = 0; q < queryMetadata.count; q++) {
  if (performance.now() - started > 6e5) throw new Error("Historical analysis exceeded 600 seconds");
  const query = queries.subarray(q * 768, (q + 1) * 768);
  const before = performance.now();
  const hits = index.search(query, 50);
  wall.push(performance.now() - before);
  if (hits.length !== 50) throw new Error("Incomplete runtime ranking");
  if (crosschecks.has(q)) {
    const reference = jsIndex.search(query, 50);
    if (reference.length !== hits.length || reference.some((hit, at) => hit.index !== hits[at].index)) {
      throw new Error("Actual JS/WASM ranking disagreement at frozen query " + q);
    }
    for (let at = 0; at < hits.length; at++) {
      maxScoreDifference = Math.max(maxScoreDifference, Math.abs(hits[at].score - reference[at].score));
    }
    if (maxScoreDifference > 1e-12) throw new Error("Actual JS/WASM score disagreement");
  }
  rankings.push(hits.map((hit) => sourceIndices[hit.index]));
  if ((q + 1) % 250 === 0) process.stderr.write("Historical full int8 runtime queries: " + (q + 1) + "\n");
}
var ordered = wall.slice().sort((a, b) => a - b);
sourceHashes["worker/probe-kernel/replay-full-quality.ts"] = sha(readFileSync(
  resolve(process.cwd(), "worker/probe-kernel/replay-full-quality.ts")
));
var result = {
  schema_version: 1,
  kind: "historical-artifact-offline-rankings",
  engine: "full-int8-runtime",
  run_id: 40448979121,
  source_commit: sourceCommit,
  artifact_sha256: archiveSha,
  restoration_sha256: sha(restorationBytes),
  scope: "Read-only analysis of retained vectors; no new inference or admission certificate.",
  implementation: {
    primary: "FullSearchIndex WASM exact int8",
    crosscheck: "FullSearchIndex JS exact int8",
    source_sha256: sourceHashes,
    wasm_sha256: sha(wasmBytes)
  },
  manifest_sha256: sha(sourceBytes),
  packed_manifest_sha256: sha(manifestBytes),
  source_rows_sha256: original.rows_sha256,
  query_vectors_sha256: sha(queryBytes),
  query_manifest_sha256: sha(frozenBytes),
  query_count: queryMetadata.count,
  passage_count: manifest.passage_count,
  rankings,
  js_wasm_checked_queries: [...crosschecks],
  js_wasm_max_score_difference: maxScoreDifference,
  node: process.version,
  admission_certificate: "NOT_ISSUED",
  production_ready: false,
  timing_scope: "Local kernel wall time only; not Cloudflare CPU or an API journey.",
  wall_ms: {
    p50: ordered[Math.ceil(ordered.length * 0.5) - 1],
    p99: ordered[Math.ceil(ordered.length * 0.99) - 1],
    first: wall[0]
  },
  elapsed_seconds: (performance.now() - started) / 1e3
};
writeFileSync(output + ".tmp", JSON.stringify(result));
renameSync(output + ".tmp", output);
process.stdout.write(JSON.stringify({
  output,
  query_count: rankings.length,
  js_wasm_checked: crosschecks.size,
  elapsed_seconds: result.elapsed_seconds
}) + "\n");
